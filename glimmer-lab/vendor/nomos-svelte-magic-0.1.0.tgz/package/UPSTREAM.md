# Source provenance

Adapted from https://github.com/SikandarJODD/animations at c0e5d02b35caf88bb09bd72a3e9c49031e1657ea. MIT copyright notice is retained in LICENSE. These are local Svelte components, not upstream-owned package names.

Local edits remove SvelteKit aliases, add explicit media/loader inputs, scope SVG IDs, and replace registry installation with package imports. Original animation algorithms otherwise retained.
