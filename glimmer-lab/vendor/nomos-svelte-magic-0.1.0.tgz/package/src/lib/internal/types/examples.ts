type CodeBlock = { filename?: string; filecode: string; lang?: string; [key: string]: unknown };
import type { Component } from "svelte";

/**
 * Represents a usage example for component documentation
 */
export type Example = {
	name: string;
	description?: string;
	preview: Component;
	code: CodeBlock | CodeBlock[];
	previewClass?: string;
	showRetry?: boolean;
};
