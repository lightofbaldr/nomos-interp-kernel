<script lang="ts">
	import { onMount, onDestroy } from "svelte";
	import { cn } from "../../internal/utils";

	interface MorphingTextProps {
		texts: string[];
		class?: string;
		paused?: boolean;
	}

	let { texts, class: className, paused = false }: MorphingTextProps = $props();
	const instanceId = $props.id();
	const filterId = `${instanceId}-threshold`;
	let reducedMotion = $state(false);

	const morphTime = 1.5;
	const cooldownTime = 0.5;

	let textIndex = $state(0);
	let morph = $state(0);
	let cooldown = $state(0);
	let time = $state(new Date());

	let text1Ref: HTMLSpanElement | null = $state(null);
	let text2Ref: HTMLSpanElement | null = $state(null);

	let animationFrameId: number | null = null;

	const setStyles = (fraction: number) => {
		if (!text1Ref || !text2Ref) return;

		text2Ref.style.filter = `blur(${Math.min(8 / fraction - 8, 100)}px)`;
		text2Ref.style.opacity = `${Math.pow(fraction, 0.4) * 100}%`;

		const invertedFraction = 1 - fraction;
		text1Ref.style.filter = `blur(${Math.min(8 / invertedFraction - 8, 100)}px)`;
		text1Ref.style.opacity = `${Math.pow(invertedFraction, 0.4) * 100}%`;

		text1Ref.textContent = texts[textIndex % texts.length];
		text2Ref.textContent = texts[(textIndex + 1) % texts.length];
	};

	const doMorph = () => {
		morph -= cooldown;
		cooldown = 0;

		let fraction = morph / morphTime;

		if (fraction > 1) {
			cooldown = cooldownTime;
			fraction = 1;
		}

		setStyles(fraction);

		if (fraction === 1) {
			textIndex++;
		}
	};

	const doCooldown = () => {
		morph = 0;
		if (text1Ref && text2Ref) {
			text2Ref.style.filter = "none";
			text2Ref.style.opacity = "100%";
			text1Ref.style.filter = "none";
			text1Ref.style.opacity = "0%";
		}
	};

	const animate = () => {
		animationFrameId = requestAnimationFrame(animate);

		const newTime = new Date();
		const dt = (newTime.getTime() - time.getTime()) / 1000;
		time = newTime;

		cooldown -= dt;

		if (cooldown <= 0) {
			doMorph();
		} else {
			doCooldown();
		}
	};

	onMount(() => {
		const preference = matchMedia('(prefers-reduced-motion: reduce)');
		const update = () => { reducedMotion = preference.matches; };
		update();
		preference.addEventListener('change', update);
		return () => preference.removeEventListener('change', update);
	});

	$effect(() => {
		texts.join('\u0000');
		const stationary = paused || reducedMotion || texts.length < 2;
		const a = text1Ref, b = text2Ref;
		if (!a || !b) return;
		a.style.filter = b.style.filter = 'none';
		a.style.opacity = '0'; b.style.opacity = '1';
		a.textContent = b.textContent = texts[0] ?? '';
		textIndex = 0; morph = 0; cooldown = cooldownTime; time = new Date();
		if (!stationary) animationFrameId = requestAnimationFrame(animate);
		return () => { if (animationFrameId !== null) cancelAnimationFrame(animationFrameId); };
	});

	onDestroy(() => {
		if (animationFrameId !== null) {
			cancelAnimationFrame(animationFrameId);
		}
	});
</script>

<div
	class={cn(
		"relative mx-auto h-16 w-full max-w-3xl text-center font-sans text-[40pt] leading-none font-bold md:h-24 lg:text-[6rem]",
		className
	)}
	style:filter={`url(#${filterId}) blur(0.6px)`}
>
	<span class="sr-only">{texts.join(', ')}</span>
	<span bind:this={text1Ref} aria-hidden="true" class="absolute inset-x-0 top-0 m-auto inline-block w-full opacity-0">{texts[0] ?? ''}</span>
	<span bind:this={text2Ref} aria-hidden="true" class="absolute inset-x-0 top-0 m-auto inline-block w-full">{texts[0] ?? ''}</span>

	<svg aria-hidden="true" class="absolute h-0 w-0" preserveAspectRatio="xMidYMid slice">
		<defs>
			<filter id={filterId}>
				<feColorMatrix
					in="SourceGraphic"
					type="matrix"
					values="1 0 0 0 0
                  0 1 0 0 0
                  0 0 1 0 0
                  0 0 0 255 -140"
				/>
			</filter>
		</defs>
	</svg>
</div>
