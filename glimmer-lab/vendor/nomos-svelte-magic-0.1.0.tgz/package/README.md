# Svelte Magic

A local library of animated text, background effects, visual controls and composed UI.

69 component entries, an independent usage site, and normal local package imports.

See [the usage guide](../../docs/animations/README.md) for setup, Svelte examples, editable source, testing and limitations.

Local preview: http://127.0.0.1:5220/

MIT adaptation of Sikandar Bhide's Svelte Animations at `c0e5d02b35caf88bb09bd72a3e9c49031e1657ea`. See LICENSE and UPSTREAM.md. No remote registry installer or custom-element wrapper.
