<script lang="ts">
	import { cn } from "../../internal/utils.js";
	import { CollapsibleContent } from "../../internal/components/ui/collapsible/index.js";
	import Response from "../response/response.svelte";

	interface Props {
		class?: string;
		content: string;
	}

	let { class: className = "", content, ...props }: Props = $props();
</script>

<CollapsibleContent
	class={cn(
		"mt-4 text-sm",
		"data-[state=closed]:fade-out-0 data-[state=closed]:slide-out-to-top-2 data-[state=open]:slide-in-from-top-2 text-muted-foreground data-[state=closed]:animate-out data-[state=open]:animate-in outline-none",
		className
	)}
	{...props}
>
	<Response class="grid gap-2" {content} />
</CollapsibleContent>
