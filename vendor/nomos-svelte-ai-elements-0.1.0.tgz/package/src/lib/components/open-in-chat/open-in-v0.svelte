<script lang="ts">
	import * as DropdownMenu from "../../internal/components/ui/dropdown-menu/index.js";
	import { getOpenInContext, providers } from "./open-in-context.svelte.js";
	import ExternalLink from "@lucide/svelte/icons/external-link";
	import V0Icon from "./v0-icon.svelte";

	interface Props {
		class?: string;
	}

	let { ...restProps }: Props = $props();

	let context = getOpenInContext();

	let url = $derived.by(() => providers.v0.createUrl(context.query));
</script>

<DropdownMenu.Item {...restProps}>
	{#snippet child({ props })}
		<a href={url} rel="noopener" target="_blank" {...props}>
			<span class="shrink-0">
				<V0Icon size="1em" />
			</span>
			<span class="flex-1">{providers.v0.title}</span>
			<!-- <ExternalLink class="size-4 shrink-0" /> -->
		</a>
	{/snippet}
</DropdownMenu.Item>
