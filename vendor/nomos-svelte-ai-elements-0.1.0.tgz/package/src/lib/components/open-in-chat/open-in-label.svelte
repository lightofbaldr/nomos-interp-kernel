<script lang="ts">
	import * as DropdownMenu from "../../internal/components/ui/dropdown-menu/index.js";

	interface Props {
		class?: string;
		children?: import("svelte").Snippet;
	}

	let { children, ...restProps }: Props = $props();
</script>

<DropdownMenu.Label {...restProps}>
	{@render children?.()}
</DropdownMenu.Label>
