<script lang="ts">
	import * as DropdownMenu from "../../internal/components/ui/dropdown-menu/index.js";
	import { cn } from "../../internal/utils.js";

	interface Props {
		class?: string;
		children?: import("svelte").Snippet;
		align?: "start" | "center" | "end";
		preventScroll?: boolean;
	}

	let {
		class: className = "",
		align = "start",
		preventScroll = true,
		children,
		...restProps
	}: Props = $props();
</script>

<DropdownMenu.Content
	{align}
	{preventScroll}
	class={cn("w-[210px] shadow-none", className)}
	{...restProps}
>
	{@render children?.()}
</DropdownMenu.Content>
