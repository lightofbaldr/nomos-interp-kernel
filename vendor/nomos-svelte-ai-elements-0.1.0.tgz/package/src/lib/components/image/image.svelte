<script lang="ts">
	import { cn } from "../../internal/utils.js";
	import type { ImageProps } from "./types.js";

	let {
		ref = $bindable(null),
		base64,
		uint8Array,
		mediaType,
		alt,
		class: className,
		...rest
	}: ImageProps = $props();
	// indexing
</script>

<img
	bind:this={ref}
	{alt}
	class={cn("h-auto max-w-full overflow-hidden rounded-md", className)}
	src={`data:${mediaType};base64,${base64}`}
	{...rest}
/>
