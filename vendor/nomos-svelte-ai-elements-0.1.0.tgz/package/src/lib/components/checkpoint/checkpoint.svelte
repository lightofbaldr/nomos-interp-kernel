<script lang="ts" module>
	import { cn, type WithElementRef } from "../../internal/utils.js";
	import type { HTMLAttributes } from "svelte/elements";
	import type { Snippet } from "svelte";
	// indexing
	export interface CheckpointProps extends WithElementRef<HTMLAttributes<HTMLDivElement>> {
		children?: Snippet;
	}
</script>

<script lang="ts">
	import { Separator } from "../../internal/components/ui/separator/index.js";

	let {
		class: className,
		children,
		ref = $bindable(null),
		...restProps
	}: CheckpointProps = $props();
</script>

<div
	bind:this={ref}
	class={cn("flex items-center gap-0.5 overflow-hidden text-muted-foreground", className)}
	{...restProps}
>
	{@render children?.()}
	<Separator />
</div>
