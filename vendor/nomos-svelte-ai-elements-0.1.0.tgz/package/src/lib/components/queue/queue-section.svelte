<script lang="ts" module>
	import { cn } from "../../internal/utils.js";
	import type { Snippet } from "svelte";
	import type { Collapsible as CollapsiblePrimitive } from "bits-ui";

	export interface QueueSectionProps extends CollapsiblePrimitive.RootProps {
		children?: Snippet;
	}
</script>

<script lang="ts">
	import { Collapsible } from "../../internal/components/ui/collapsible/index.js";

	let {
		class: className,
		open = $bindable(true),
		children,
		ref = $bindable(null),
		...restProps
	}: QueueSectionProps = $props();
</script>

<Collapsible bind:ref bind:open class={cn(className)} {...restProps}>
	{@render children?.()}
</Collapsible>
