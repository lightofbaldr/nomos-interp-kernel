// import Temporary from "./temporary.svelte";
// import Animated from "./animated.svelte";
// // indexing
// export const Edge = {
// 	Temporary,
// 	Animated,
// };
// Upstream's two edge studies are entirely commented out, not usable components.
// Keep their source for provenance; use @xyflow/svelte's built-in edges instead.
export {};
