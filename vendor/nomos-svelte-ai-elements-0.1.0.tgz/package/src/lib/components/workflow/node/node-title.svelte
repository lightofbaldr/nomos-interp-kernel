<script lang="ts">
	import { CardTitle } from "../../../internal/components/ui/card/index.js";
	import type { WithElementRef } from "../../../internal/utils.js";
	import type { HTMLAttributes } from "svelte/elements";

	type Props = WithElementRef<HTMLAttributes<HTMLDivElement>>;

	let { ref = $bindable(null), class: className, children, ...restProps }: Props = $props();
</script>

<CardTitle bind:ref class={className} {...restProps}>
	{@render children?.()}
</CardTitle>
