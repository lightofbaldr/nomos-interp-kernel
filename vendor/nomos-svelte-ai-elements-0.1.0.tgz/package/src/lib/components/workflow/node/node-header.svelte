<script lang="ts">
	import { CardHeader } from "../../../internal/components/ui/card/index.js";
	import { cn, type WithElementRef } from "../../../internal/utils.js";
	import type { HTMLAttributes } from "svelte/elements";

	type Props = WithElementRef<HTMLAttributes<HTMLDivElement>>;

	let { ref = $bindable(null), class: className, children, ...restProps }: Props = $props();
</script>

<CardHeader
	bind:ref
	class={cn("bg-secondary gap-0.5 rounded-t-md border-b p-3!", className)}
	{...restProps}
>
	{@render children?.()}
</CardHeader>
