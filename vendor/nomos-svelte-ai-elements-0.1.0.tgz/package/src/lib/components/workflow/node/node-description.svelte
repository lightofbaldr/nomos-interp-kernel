<script lang="ts">
	import { CardDescription } from "../../../internal/components/ui/card/index.js";
	import type { WithElementRef } from "../../../internal/utils.js";
	import type { HTMLAttributes } from "svelte/elements";

	type Props = WithElementRef<HTMLAttributes<HTMLParagraphElement>>;

	let { ref = $bindable(null), class: className, children, ...restProps }: Props = $props();
</script>

<CardDescription bind:ref class={className} {...restProps}>
	{@render children?.()}
</CardDescription>
