<script lang="ts">
	import { CardContent } from "../../../internal/components/ui/card/index.js";
	import { cn, type WithElementRef } from "../../../internal/utils.js";
	import type { HTMLAttributes } from "svelte/elements";

	type Props = WithElementRef<HTMLAttributes<HTMLDivElement>>;

	let { ref = $bindable(null), class: className, children, ...restProps }: Props = $props();
</script>

<CardContent bind:ref class={cn("p-3", className)} {...restProps}>
	{@render children?.()}
</CardContent>
