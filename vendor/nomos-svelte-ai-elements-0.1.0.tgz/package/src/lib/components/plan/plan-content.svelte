<script lang="ts">
	import { CollapsibleContent } from "../../internal/components/ui/collapsible/index.js";
	import { CardContent } from "../../internal/components/ui/card/index.js";
	import type { PlanContentProps } from "./types.js";

	let { children, ...restProps }: PlanContentProps = $props();
</script>

<CollapsibleContent>
	<CardContent data-slot="plan-content" {...restProps}>
		{@render children?.()}
	</CardContent>
</CollapsibleContent>
