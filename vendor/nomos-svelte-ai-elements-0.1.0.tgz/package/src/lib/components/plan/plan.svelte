<script lang="ts">
	import { Collapsible } from "../../internal/components/ui/collapsible/index.js";
	import { Card } from "../../internal/components/ui/card/index.js";
	import { cn } from "../../internal/utils.js";
	import { setPlanContext } from "./plan-context.svelte.js";
	import type { PlanProps } from "./types.js";
	import { untrack } from "svelte";

	let { class: className, isStreaming = false, children, ...restProps }: PlanProps = $props();

	// Set context for child components
	setPlanContext({ isStreaming: untrack(() => isStreaming) });
	// indexing
</script>

<Collapsible data-slot="plan" {...restProps}>
	<Card class={cn("shadow-none", className)}>
		{@render children?.()}
	</Card>
</Collapsible>
