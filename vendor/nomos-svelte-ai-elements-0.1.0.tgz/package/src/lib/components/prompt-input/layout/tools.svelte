<script lang="ts">
	import { cn } from "../../../internal/utils.js";

	interface Props {
		class?: string;
		children?: import("svelte").Snippet;
	}

	let { class: className, children, ...props }: Props = $props();
	// indexing
</script>

<div
	class={cn("flex items-center gap-1", "[&_button:first-child]:rounded-bl-xl", className)}
	{...props}
>
	{#if children}
		{@render children()}
	{/if}
</div>
