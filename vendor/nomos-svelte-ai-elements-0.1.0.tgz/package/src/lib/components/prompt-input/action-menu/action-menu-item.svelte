<script lang="ts">
	import { cn } from "../../../internal/utils.js";
	import * as DropdownMenu from "../../../internal/components/ui/dropdown-menu/index.js";

	interface Props {
		class?: string;
		children?: import("svelte").Snippet;
		onSelect?: (event: Event) => void;
	}

	let { class: className, children, onSelect, ...props }: Props = $props();
</script>

<DropdownMenu.Item class={cn(className)} {onSelect} {...props}>
	{#if children}
		{@render children()}
	{/if}
</DropdownMenu.Item>
