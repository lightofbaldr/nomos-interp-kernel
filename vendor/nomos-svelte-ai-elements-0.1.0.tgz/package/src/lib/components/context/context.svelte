<script lang="ts">
	import * as HoverCard from "../../internal/components/ui/hover-card/index.js";
	import { ContextClass, setContextValue, type ContextSchema } from "./context-context.svelte.js";
	import { untrack } from "svelte";

	interface Props extends ContextSchema {
		children?: import("svelte").Snippet;
		// HoverCard props
		closeDelay?: number;
		openDelay?: number;
		[key: string]: any;
	}
	// indexing
	let {
		usedTokens,
		maxTokens,
		usage,
		modelId,
		costEstimator,
		children,
		closeDelay = 0,
		openDelay = 0,
		...props
	}: Props = $props();

	const contextInstance = new ContextClass({
		usedTokens: untrack(() => usedTokens),
		maxTokens: untrack(() => maxTokens),
		usage: untrack(() => usage),
		modelId: untrack(() => modelId),
		costEstimator: untrack(() => costEstimator),
	});

	// Update context when props change
	$effect(() => {
		contextInstance.usedTokens = usedTokens;
		contextInstance.maxTokens = maxTokens;
		contextInstance.usage = usage;
		contextInstance.modelId = modelId;
		contextInstance.costEstimator = costEstimator;
	});

	setContextValue(contextInstance);
</script>

<HoverCard.Root {openDelay} {closeDelay} {...props}>
	{@render children?.()}
</HoverCard.Root>
