import StackingCards from "./stacking-cards.svelte";
import StackignCardItem from "./stacking-card-item.svelte";

// Retain the upstream spelling as an alias, while exposing the correctly named component.
export { StackingCards, StackignCardItem, StackignCardItem as StackingCardItem };
